class custom_functions{
    constructor(){
        var fs = require('fs');
        require("./conf.json")
        this.conf_file = JSON.parse(fs.readFileSync('./conf.json').toString());

        this.entities = {}
        if("entity" in this.conf_file)
            this.entities = this.conf_file["entity"]

        this.properties = {}
        if("property" in this.conf_file)
            this.properties = this.conf_file["property"]

        this.lang = this.conf_file["lang"]

        this.limitResults = 5
        if("result_limit" in this.conf_file)
            this.limitResults = this.conf_file["result_limit"]

        this.invocationName = this.conf_file["invocation_name"]

        this.endpoint = this.conf_file["endpoint"]

    }

    getLang(){
        return this.lang;
    }

    getLimitResults(){
        return this.limitResults;
    }

    getInvocationName(){
        return this.invocationName;
    }

    getProperty(property){
        console.log("get property")
        console.log(property)
        
        if (property in this.properties){
            console.log(this.properties[property].urls)
            return this.properties[property].urls;
        }
        else{
            console.log("NO property")
        }
    }

    getEntity(entity){
        console.log("get entity")
        console.log(entity)
        
        if (entity in this.entities){
            console.log(this.entities[entity].urls)
            return this.entities[entity].urls;
        }
        else{
            console.log("NO entity")
        }
    }

    extractLabel(url){
        console.log("extractLabel");
        console.log(url);

        var label;

        var date_regex = new RegExp("^[0-9]{4}-?[0-1][0-2]-[0-3][0-9]T[0-9][0-9]:[0-9][0-9]:[0-9][0-9]Z$")
        var url_regex = new RegExp("^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})$");
        if (date_regex.test(url)) {
            var parts = url.split("T");
            label = parts[0];
        } else if(url_regex.test(url)){

            var parts = url.split("/");
            var localName = parts[parts.length-1];

            label = localName

            if (localName.includes("-")){
                parts = localName.split("-");
                label = parts[1];
            }
        } else{
            label  = url;
        }

        console.log(label);
         
        return label;
    }

    runSelectQuery (sparql){
        const wbk = require('wikibase-sdk')({
            instance: 'https://www.wikidata.org',
            sparqlEndpoint: 'https://query.wikidata.org/sparql'
        });

        const url = wbk.sparqlQuery(sparql);
        
        //const url = this.endpoint+"?query="+ encodeURIComponent(sparql) +"&format=json";
        console.log(url)

        var request = require('sync-request');
        var res = request('GET', url, {
            headers: {
                'user-agent': 'example-user-agent',
            },
        });

        var b = JSON.parse(res.getBody());
        return b.results.bindings;
    }

    runAskQuery (sparql){
        const wbk = require('wikibase-sdk')({
            instance: 'https://www.wikidata.org',
            sparqlEndpoint: 'https://query.wikidata.org/sparql'
        });

        const url = wbk.sparqlQuery(sparql);
        
        //const url = this.endpoint+"?query="+ encodeURIComponent(sparql) +"&format=json";

        var request = require('sync-request');
        var res = request('GET', url, {
            headers: {
                'user-agent': 'example-user-agent',
            },
        });

        var b = JSON.parse(res.getBody());
        return b.boolean;
    }

    getLocationPredicates (){
        return this.getProperty("location");
    }

    getInstancesPredicates (){
        return this.getProperty("instanceof")
    }

    getImgPredicates (){
        return this.getProperty("img")
    }

    getDescriptionPredicates (){
        return this.getProperty("description")
    }
	
	getLabelPredicates(){
        return this.getProperty("label")
    }
}

module.exports = custom_functions