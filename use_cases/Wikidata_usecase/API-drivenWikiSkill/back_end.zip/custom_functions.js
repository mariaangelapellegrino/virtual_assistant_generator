class custom_functions{
    constructor(){
        this.lang = "en"

        this.limitResults = 5

        this.wbk = require('wikibase-sdk')({
            instance: 'https://www.wikidata.org',
            sparqlEndpoint: 'https://query.wikidata.org/sparql'
        });

        this.invocationName = "querying api wikidata";

        this.request = require('sync-request');

    }

    getLang(){
        return this.lang;
    }

    getLimitResults(){
        return this.limitResults;
    }

    getInvocationName(){
        return this.invocationName;
    }

    getProperty(property){
        var t0 = new Date().getTime();

        //console.log(property)
        var resultLimit = 5;
        var urlNaz = this.wbk.searchEntities({
            search: property,
            type: 'property',
            format: 'json',
            language: this.lang,
            limit: resultLimit,
            continue: 0
        });

        var res = this.request('GET', urlNaz);
        var b= JSON.parse(res.getBody());


        var result = [];
        
        if(b!=null){
            if (b.search.length<resultLimit)
                resultLimit = b.search.length;

            for(var i=0; i<resultLimit; i++) 
                result.push("wdt:"+b.search[i].id);
        }

        var t1 = new Date().getTime();
        console.log("Call to resolve "+ property + " as " + result + " took " + (t1 - t0) + " milliseconds.")
        return result
        
    }

    getEntity(entity){
        var t0 = new Date().getTime();

        //console.log(entity)
        
        var resultLimit = 5;
        var urlNaz = this.wbk.searchEntities({
            search: entity,
            format: 'json',
            language: this.lang,
            limit: resultLimit,
            continue: 0
        });

        var res = this.request('GET', urlNaz);
        var b= JSON.parse(res.getBody());

        var result = [];
        
        if(b!=null){
            if (b.search.length<resultLimit)
                resultLimit = b.search.length;
            
            for(var i=0; i<resultLimit; i++) 
                result.push("wd:"+b.search[i].id);
        }

        var t1 = new Date().getTime();
        console.log("Call to resolve "+ entity + " as " + result + " took " + (t1 - t0) + " milliseconds.")
        return result

    }

    extractLabel(input){
        console.log("extractLabel");
        console.log(input);

        const dateRegex = /[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z/;

        if (dateRegex.test(input)>0){
            var parts = input.split("T");
            return parts[0];
        }

        var parts = input.split("/");
        var localName = parts[parts.length-1];
        var label = localName;
        if (localName.includes("-")){
            parts = localName.split("-");
            label = parts[1];
        }
        console.log(label);
         
        return label;
    }

    runSelectQuery (sparql){
        var t0 = new Date().getTime();

        const url = this.wbk.sparqlQuery(sparql);
		
		console.log(url)

        var res = this.request('GET', url, {
            headers: {'user-agent': 'example-user-agent'}
        });

        var b = JSON.parse(res.getBody());
        var result = b.results.bindings;
		
		console.log(result)

        var t1 = new Date().getTime();
        console.log("Call to runSelectQuery took " + (t1 - t0) + " milliseconds.")
        return result
    }

    runAskQuery (sparql){
        var t0 = new Date().getTime();

        const url = this.wbk.sparqlQuery(sparql);

        var res = this.request('GET', url, {
            headers: {
                'user-agent': 'example-user-agent',
            },
        });

        var b = JSON.parse(res.getBody());
        var result = b.boolean;

        var t1 = new Date().getTime();
        console.log("Call to runAskQuery took " + (t1 - t0) + " milliseconds.")
        return result
    }

    getLocationPredicates (){
        return this.getProperty("location")
    }

    getInstancesPredicates (){
        return this.getProperty("instance of")
    }

    getImgPredicates (){
        return this.getProperty("img")
    }

    getDescriptionPredicates (){
        return this.getProperty("description")
    }

    getLabelPredicates(){
        return ["rdfs:label"] //this.getProperty("label")
    }
}

module.exports = custom_functions